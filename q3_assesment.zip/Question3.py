import math
import numpy as np
import matplotlib.pyplot as plt


##################################################################
# Part 1 - Direction of Antenna of motor with one uav position #

# Function phi_theta to determine phi and theta rotation of antenna
def phi_theta(motor_pos, uav_pos):
    delta_y = uav_pos[1] - motor_pos[1]
    delta_x = uav_pos[0] - motor_pos[0]

    # Initial position of antenna is towards x-axis
    # phi - First angle of turn about positive z-axis
    # theta - Second angle of turn about body positive y-axis
    if delta_x == 0:
        if delta_y == 0:
            # If the UAV is vertically above the Motor
            phi = 0
            theta = -math.pi/2
        else:
            # If the UAV has the same x-coordinate as Motor
            phi = np.sign(delta_y)*math.pi/2
            theta = -math.atan(uav_pos[2] / math.sqrt(math.pow(delta_x, 2) + math.pow(delta_y, 2)))
    else:
        # General case
        phi = math.atan(delta_y / delta_x)
        theta = -math.atan(uav_pos[2] / math.sqrt(math.pow(delta_x, 2) + math.pow(delta_y, 2)))

    # Converting Radians to Degrees
    phi_deg = phi * 180 / math.pi
    theta_deg = theta * 180 / math.pi

    # Maximum value of Phi to be 180 degrees
    if delta_x < 0:
        phi_deg += 180

    return phi_deg, theta_deg


print("PART 1 ... Initial antenna facing x-axis")
# Input number of test runs required
t = int(input("Number of test runs on single uav position : "))
for i in range(t):
    print("Enter the position of motor(x,y,0): ")
    arr1 = input()
    Motor = list(map(float, arr1.split(" ")))

    print("Enter the position of uav(x1,y1,z1): ")
    arr2 = input()
    uav = list(map(float, arr2.split(" ")))

    rotation = phi_theta(Motor, uav)
    print("First angle of turn about z-axis(phi in degrees):", rotation[0])
    print("Second angle of turn about body y-axis(theta in degrees):", rotation[1])

# Part 3 - To plot the variation of antenna direction #
    fig = plt.figure()
    # 3D Axes
    ax = fig.add_subplot(projection='3d')

    # Axes limits
    ax.set_xlim3d(-10, 10)
    ax.set_ylim3d(-10, 10)
    ax.set_zlim3d(0, 10)

    # Axes Labels and Title
    ax.set_xlabel('X-axis')
    ax.set_ylabel('Y-axis')
    ax.set_zlabel('Z-axis')
    ax.set_title('Direction of Antenna on Motor')

    # Value of phi in radians
    phi_rad = rotation[0] * math.pi / 180

    # Arrow pointing the initial direction of the antenna
    ax.quiver(Motor[0], Motor[1], Motor[2], 1, 0, 0, color='red', length=3, normalize=True)
    ax.text(Motor[0]+3, Motor[1], 0, "Initial direction", 'x')
    plt.show(block=False)
    plt.pause(2)

    # Arrow after rotating the antenna through phi
    # Direction of Antenna
    A1 = math.cos(phi_rad)
    B1 = math.sin(phi_rad)
    C1 = 0
    ax.quiver(Motor[0], Motor[1], Motor[2], A1, B1, C1, color='blue', length=3, normalize=True)
    ax.text(Motor[0]+math.cos(phi_rad), Motor[1]+math.sin(phi_rad), 0, "After rotating through phi", 'x')
    plt.show(block=False)
    plt.pause(2)

    # Arrow after the final rotation of theta
    # Direction of Antenna
    A2 = uav[0] - Motor[0]
    B2 = uav[1] - Motor[1]
    C2 = uav[2]
    ax.quiver(Motor[0], Motor[1], Motor[2], A2, B2, C2, color='green', length=3, normalize=True)
    ax.text(uav[0] - Motor[0], uav[1] - Motor[1], uav[2], "Final direction", 'x')
    plt.show()
# ------------------------------------------------------------------


###################################################################
# Part 2 - Antenna rotation with multiple UAV positions

print("\nPART 2 ... Initial antenna facing z-axis")
N = int(input("Number of UAV positions : "))

print("Enter the positions of motor and uav: ")

# Input of Motor and UAV positions
uav_list = []
for i in range(N + 1):
    arr = input()
    coord = list(map(float, arr.split(" ")))
    uav_list.append(coord)

# Motor position is given along with UAV positions
motor1 = uav_list[0]
rotations = []

# Initial rotation taken as a rotation from x-axis to z-axis
rot_prev = [0, -90]
for j in range(1, N + 1):
    # Using the function phi_theta defined in part 1 to get phi and theta angles
    rot = phi_theta(motor1, uav_list[j])

    # Difference between phi and theta of consecutive UAV positions
    # Rotating first by theta and then by phi unlike part 1
    rotations.append([rot[1] - rot_prev[1], rot[0] - rot_prev[0]])
    rot_prev = rot

print("Rotations(theta and phi in degrees):\n", rotations)

# Part 4 - Plotting the direction of antenna for all UAV positions

fig1 = plt.figure()
# 3D Axes
ax1 = fig1.add_subplot(projection='3d')

# Axes limits
ax1.set_xlim3d(-10, 10)
ax1.set_ylim3d(-10, 10)
ax1.set_zlim3d(0, 10)

# Axes Labels and Title
ax1.set_xlabel('X-axis')
ax1.set_ylabel('Y-axis')
ax1.set_zlabel('Z-axis')
ax1.set_title('Direction of Antenna on Motor')

# Arrow pointing the initial direction of the antenna
ax1.quiver(motor1[0], motor1[1], motor1[2], 0, 0, 1, color='red', length=3, normalize=True)
ax1.text(motor1[0], motor1[1], 3, "Initial direction", 'x')
plt.show(block=False)
plt.pause(2)

for k in range(N):
    # Value of phi in radians
    phi_rad = rotations[k][1] * math.pi / 180

    # Arrow after rotating the antenna through theta
    # Direction of antenna - using rotational transformation about z axis
    U1 = uav_list[k+1][0] * math.cos(phi_rad) + uav_list[k+1][1] * math.sin(phi_rad)
    V1 = -uav_list[k+1][0] * math.sin(phi_rad) + uav_list[k+1][1] * math.cos(phi_rad)
    W1 = uav_list[k+1][2]
    ax1.quiver(motor1[0], motor1[1], motor1[2], U1, V1, W1, color='blue', length=3, normalize=True)
    plt.show(block=False)
    plt.pause(2)

    # Arrow after the rotation of Phi towards the UAV
    # Direction of antenna - Final position of UAV
    U2 = uav_list[k+1][0] - motor1[0]
    V2 = uav_list[k+1][1] - motor1[1]
    W2 = uav_list[k+1][2]
    ax1.quiver(motor1[0], motor1[1], motor1[2], U2, V2, W2, color='green', length=3, normalize=True)
    plt.show(block=False)
    plt.pause(3)

plt.show()
# ------------------------------------------------------------------
